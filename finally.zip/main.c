#include <iocc2530.h>
#include "hal_mcu.h"
#include "hal_assert.h"
#include "hal_rf.h"
#include "basic_rf.h"
#include <stdio.h>
#include "BH1750.h"
#include "oled.h"
#include "clock.h"
#include "delay.h"
#include "oled.h"
#include "string.h"
#include "led.h"
#include "key.h"
#include "htu21d.h"


#define RF_CHANNEL            24                                // 2.4 GHz RF channel
#define PAN_ID                0x2006
#define SEND_ADDR             0x2530
#define RECV_ADDR             0x2520

#define NODE_TYPE             1                                 //0:���սڵ㣬��0�����ͽڵ�

static basicRfCfg_t basicRfConfig;


void rfSendData(void)
{
    basicRfConfig.myAddr = SEND_ADDR;
    uint8 send[2];
    while(1){
      //float temp=bh1750_get_data();
      float temp=bh1750_get_data();
      //if(temp<0) temp=-temp;
      send[0]=temp;//�ռ����մ��������ݱ��浽����������
      send[1]=htu21d_get_data(TEMPERATURE);
      send[1]=-46 + 175 * send[1]/(2^16);
      basicRfSendPacket(RECV_ADDR, send, sizeof send); //��������
      halMcuWaitMs(1000);
    }
}

void rfRecvData(void) {
    char title[10]="Lighting\0";
    char title2[11]="Temprature\0";
    basicRfConfig.myAddr = RECV_ADDR;
    uint8 receive[2]={0,0};
    int rlen;
    basicRfReceiveOn();
    while(1){
      while(!basicRfPacketIsReady());
        rlen = basicRfReceive(receive, sizeof receive, NULL);
        OLED_Clear();
        D1=OFF;
        D2=OFF;
        OLED_ShowString(0,0,title,16);
        int gewei,shiwei,baiwei;
        gewei=receive[0]%10;
        shiwei=(receive[0]%100)/10;
        baiwei=receive[0]/100;
        OLED_ShowChar(0,2,baiwei+48,16);
        OLED_ShowChar(8,2,shiwei+48,16);
        OLED_ShowChar(16,2,gewei+48,16);
        OLED_ShowString(0,4,title2,16);
        OLED_ShowChar(0,6,(receive[1]/100)+48,16);
        OLED_ShowChar(8,6,((receive[1]%100)/10)+48,16);
        OLED_ShowChar(16,6,(receive[1]%10)+48,16);
        if(receive[0]<100){
          D1=ON;
          D2=ON;
        }
        delay_s(1);
    }
}

void main(void)
{
    xtal_init();                                                  //ϵͳʱ�ӳ�ʼ�� 
    OLED_Init();                                                  //OLED��ʼ��
    bh1750_init();                                                //���նȴ�������ʼ��
    halMcuInit();
    led_init();                                                   //LED�Ŀ��ƶ˿ڳ�ʼ��
    key_init();                                                   //�����Ŀ��ƶ˿ڳ�ʼ��
    
    if (FAILED == halRfInit()) {
        HAL_ASSERT(FALSE);
    }

    // Config basicRF
    basicRfConfig.panId = PAN_ID;
    basicRfConfig.channel = RF_CHANNEL;
    basicRfConfig.ackRequest = TRUE;
#ifdef SECURITY_CCM
    basicRfConfig.securityKey = key;
#endif

    
    // Initialize BasicRF
#if NODE_TYPE
    basicRfConfig.myAddr = SEND_ADDR;
#else
    basicRfConfig.myAddr = RECV_ADDR; 
#endif
    
    if(basicRfInit(&basicRfConfig)==FAILED) {
      HAL_ASSERT(FALSE);
    }
#if NODE_TYPE
  rfSendData();
#else
  rfRecvData();
#endif
}