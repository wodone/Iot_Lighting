#ifndef _INFO_H
#define _INFO_H
void lcd_dis(void);

#endif